package com.diarymanager;

import java.io.Serializable;

public class DiaryConfig implements Serializable {
    private static final long serialVersionUID = 1L;

    private String userName;
    private String entriesDirectory;
    private String backupsDirectory;

    public DiaryConfig() {
        this.userName = "";
        this.entriesDirectory = "entries";
        this.backupsDirectory = "backups";
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEntriesDirectory() {
        return entriesDirectory;
    }

    public void setEntriesDirectory(String entriesDirectory) {
        this.entriesDirectory = entriesDirectory;
    }

    public String getBackupsDirectory() {
        return backupsDirectory;
    }

    public void setBackupsDirectory(String backupsDirectory) {
        this.backupsDirectory = backupsDirectory;
    }
}
