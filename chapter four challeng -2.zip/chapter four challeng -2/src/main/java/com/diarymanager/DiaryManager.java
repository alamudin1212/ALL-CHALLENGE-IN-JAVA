package com.diarymanager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class DiaryManager {
    private static final String CONFIG_FILE_NAME = "diary_config.ser";

    private static final String ENTRY_PREFIX = "diary_";
    private static final String ENTRY_SUFFIX = ".txt";

    private static final DateTimeFormatter FILE_TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss");
    private static final DateTimeFormatter DISPLAY_TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter BACKUP_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy_MM_dd");

    private static final String MULTILINE_END_MARKER = "::end";

    private final BufferedReader consoleReader;

    private DiaryConfig config;
    private Path entriesDir;
    private Path backupsDir;

    public static void main(String[] args) {
        new DiaryManager().run();
    }

    public DiaryManager() {
        this.consoleReader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
    }

    private void run() {
        this.config = loadConfig();
        this.entriesDir = Paths.get(nullToDefault(config.getEntriesDirectory(), "entries"));
        this.backupsDir = Paths.get(nullToDefault(config.getBackupsDirectory(), "backups"));

        ensureDirectories();

        Runtime.getRuntime().addShutdownHook(new Thread(this::saveConfigQuietly));

        promptForUserNameIfMissing();

        boolean keepRunning = true;
        while (keepRunning) {
            printMenu();

            String choice = readLine("Choose an option (1-5): ");
            if (choice == null) {
                // End of input (e.g., redirected stdin)
                break;
            }

            switch (choice.trim()) {
                case "1":
                    writeEntry();
                    break;
                case "2":
                    readPreviousEntry();
                    break;
                case "3":
                    searchEntries();
                    break;
                case "4":
                    createBackupZip();
                    break;
                case "5":
                    keepRunning = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number from 1 to 5.");
                    break;
            }

            if (keepRunning) {
                System.out.println();
            }
        }

        saveConfigQuietly();
        System.out.println("Goodbye!");
    }

    private void printMenu() {
        System.out.println("================================");
        System.out.println("    PERSONAL DIARY MANAGER");
        System.out.println("================================");
        System.out.println("1. Write New Entry");
        System.out.println("2. Read Previous Entry");
        System.out.println("3. Search Entries");
        System.out.println("4. Create Backup (Bonus)");
        System.out.println("5. Exit");
    }

    private void writeEntry() {
        System.out.println();
        System.out.println("Write your diary entry. Enter " + MULTILINE_END_MARKER + " (or an empty line) to finish:");

        List<String> lines = new ArrayList<>();
        while (true) {
            String line = readLine("");
            if (line == null) {
                break;
            }

            if (line.isEmpty() || MULTILINE_END_MARKER.equalsIgnoreCase(line.trim())) {
                break;
            }

            lines.add(line);
        }

        if (lines.isEmpty()) {
            System.out.println("No text entered. Entry was not saved.");
            return;
        }

        Path entryPath;
        try {
            entryPath = createUniqueEntryPath();
        } catch (IOException | SecurityException ex) {
            printFriendlyError("Could not create a new entry file.", ex);
            return;
        }

        try (BufferedWriter writer = Files.newBufferedWriter(entryPath, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE)) {
            for (String l : lines) {
                writer.write(l);
                writer.newLine();
            }

            System.out.println("Entry saved successfully: " + entryPath.getFileName());
        } catch (FileAlreadyExistsException ex) {
            System.out.println("Error: An entry with the same timestamp already exists. Please try again.");
        } catch (IOException | SecurityException ex) {
            printFriendlyError("Could not save the entry.", ex);
        }
    }

    private void readPreviousEntry() {
        List<Path> entries = listEntryFiles();
        if (entries.isEmpty()) {
            System.out.println("No diary entries found.");
            return;
        }

        System.out.println();
        System.out.println("Available Entries:");
        for (int i = 0; i < entries.size(); i++) {
            Path p = entries.get(i);
            String display = formatEntryDisplay(p.getFileName().toString());
            System.out.println((i + 1) + ". " + display);
        }

        int selection = readInt("Enter entry number to read (0 to cancel): ");
        if (selection == 0) {
            return;
        }

        if (selection < 1 || selection > entries.size()) {
            System.out.println("Invalid selection. Returning to main menu...");
            return;
        }

        Path chosen = entries.get(selection - 1);
        displayEntry(chosen);
    }

    private void searchEntries() {
        String query = readLine("Enter keyword(s) to search: ");
        if (query == null) {
            return;
        }

        String trimmed = query.trim();
        if (trimmed.isEmpty()) {
            System.out.println("Search query was empty.");
            return;
        }

        List<String> tokens = Stream.of(trimmed.split("\\s+"))
                .filter(t -> !t.isBlank())
                .map(t -> t.toLowerCase(Locale.ROOT))
                .collect(Collectors.toList());

        List<SearchResult> matches = new ArrayList<>();
        for (Path entry : listEntryFiles()) {
            Optional<SearchResult> result = searchFile(entry, tokens);
            result.ifPresent(matches::add);
        }

        if (matches.isEmpty()) {
            System.out.println("No matching entries found.");
            return;
        }

        System.out.println();
        System.out.println("Found " + matches.size() + " matching entr" + (matches.size() == 1 ? "y" : "ies") + ":");
        for (int i = 0; i < matches.size(); i++) {
            SearchResult r = matches.get(i);
            String display = formatEntryDisplay(r.path.getFileName().toString());
            System.out.println((i + 1) + ". [" + display + "] " + r.snippet);
        }

        int selection = readInt("Enter number to read an entry (0 to cancel): ");
        if (selection == 0) {
            return;
        }
        if (selection < 1 || selection > matches.size()) {
            System.out.println("Invalid selection. Returning to main menu...");
            return;
        }

        displayEntry(matches.get(selection - 1).path);
    }

    private Optional<SearchResult> searchFile(Path entry, List<String> tokensLower) {
        boolean[] found = new boolean[tokensLower.size()];
        String snippet = null;

        try (BufferedReader reader = Files.newBufferedReader(entry, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String lower = line.toLowerCase(Locale.ROOT);
                for (int i = 0; i < tokensLower.size(); i++) {
                    if (!found[i] && lower.contains(tokensLower.get(i))) {
                        found[i] = true;
                        if (snippet == null) {
                            snippet = buildSnippet(line);
                        }
                    }
                }
            }
        } catch (IOException | SecurityException ex) {
            System.out.println("Error: Could not search entry file '" + entry.getFileName() + "'.");
            System.out.println("Reason: " + friendlyReason(ex));
            return Optional.empty();
        }

        for (boolean f : found) {
            if (!f) {
                return Optional.empty();
            }
        }

        if (snippet == null) {
            snippet = "(match found)";
        }

        return Optional.of(new SearchResult(entry, snippet));
    }

    private void createBackupZip() {
        ensureDirectories();

        List<Path> entries = listEntryFiles();
        if (entries.isEmpty()) {
            System.out.println("No entries found to back up.");
            return;
        }

        String baseName = "diary_backup_" + LocalDate.now().format(BACKUP_DATE_FORMAT) + ".zip";
        Path zipPath = backupsDir.resolve(baseName);
        try {
            zipPath = chooseNonExistingPath(zipPath);
        } catch (IOException | SecurityException ex) {
            printFriendlyError("Could not prepare backup file.", ex);
            return;
        }

        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(zipPath, StandardOpenOption.CREATE_NEW))) {
            for (Path entry : entries) {
                ZipEntry ze = new ZipEntry(entry.getFileName().toString());
                zos.putNextEntry(ze);
                Files.copy(entry, zos);
                zos.closeEntry();
            }

            System.out.println("Backup created successfully: " + zipPath);
        } catch (IOException | SecurityException ex) {
            printFriendlyError("Could not create backup ZIP.", ex);
        }
    }

    private void displayEntry(Path entryPath) {
        System.out.println();
        System.out.println("--------------------------------");
        System.out.println("Entry: " + formatEntryDisplay(entryPath.getFileName().toString()));
        System.out.println("--------------------------------");

        try (BufferedReader reader = Files.newBufferedReader(entryPath, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (NoSuchFileException ex) {
            System.out.println("Error: Could not read entry file '" + entryPath.getFileName() + "'");
            System.out.println("Reason: File not found.");
            System.out.println("Returning to main menu...");
        } catch (IOException | SecurityException ex) {
            System.out.println("Error: Could not read entry file '" + entryPath.getFileName() + "'");
            System.out.println("Reason: " + friendlyReason(ex));
            System.out.println("Returning to main menu...");
        }
    }

    private List<Path> listEntryFiles() {
        ensureDirectories();

        if (!Files.isDirectory(entriesDir)) {
            return List.of();
        }

        try (Stream<Path> stream = Files.list(entriesDir)) {
            return stream
                    .filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().startsWith(ENTRY_PREFIX)
                            && p.getFileName().toString().endsWith(ENTRY_SUFFIX))
                    .sorted(Comparator.comparing(Path::getFileName))
                    .collect(Collectors.toList());
        } catch (IOException | SecurityException ex) {
            System.out.println("Error: Could not list diary entries.");
            System.out.println("Reason: " + friendlyReason(ex));
            return List.of();
        }
    }

    private String formatEntryDisplay(String fileName) {
        Optional<LocalDateTime> ts = parseTimestampFromFilename(fileName);
        if (ts.isPresent()) {
            return ts.get().format(DISPLAY_TIMESTAMP_FORMAT);
        }
        return fileName;
    }

    private Optional<LocalDateTime> parseTimestampFromFilename(String fileName) {
        if (!fileName.startsWith(ENTRY_PREFIX) || !fileName.endsWith(ENTRY_SUFFIX)) {
            return Optional.empty();
        }

        String raw = fileName.substring(ENTRY_PREFIX.length(), fileName.length() - ENTRY_SUFFIX.length());
        try {
            return Optional.of(LocalDateTime.parse(raw, FILE_TIMESTAMP_FORMAT));
        } catch (DateTimeParseException ex) {
            return Optional.empty();
        }
    }

    private Path createUniqueEntryPath() throws IOException {
        // Ensure the filename format stays EXACT: diary_YYYY_MM_dd_HH_mm_ss.txt
        // If a collision happens (same second), wait and try again.
        for (int attempt = 0; attempt < 3; attempt++) {
            String timestamp = LocalDateTime.now().format(FILE_TIMESTAMP_FORMAT);
            String fileName = ENTRY_PREFIX + timestamp + ENTRY_SUFFIX;
            Path candidate = entriesDir.resolve(fileName);

            try {
                // Probe by attempting to open with CREATE_NEW later; here we just return the path.
                return candidate;
            } catch (SecurityException ex) {
                throw ex;
            }
        }

        // Last resort (still correct format)
        String timestamp = LocalDateTime.now().plusSeconds(1).format(FILE_TIMESTAMP_FORMAT);
        return entriesDir.resolve(ENTRY_PREFIX + timestamp + ENTRY_SUFFIX);
    }

    private Path chooseNonExistingPath(Path desired) throws IOException {
        if (!Files.exists(desired)) {
            return desired;
        }

        String fileName = desired.getFileName().toString();
        int dot = fileName.lastIndexOf('.');
        String base = dot >= 0 ? fileName.substring(0, dot) : fileName;
        String ext = dot >= 0 ? fileName.substring(dot) : "";

        for (int i = 1; i <= 100; i++) {
            Path candidate = desired.getParent().resolve(base + "_" + i + ext);
            if (!Files.exists(candidate)) {
                return candidate;
            }
        }

        throw new IOException("Could not find an available file name for: " + desired.getFileName());
    }

    private void ensureDirectories() {
        try {
            Files.createDirectories(entriesDir);
            Files.createDirectories(backupsDir);
        } catch (IOException | SecurityException ex) {
            System.out.println("Error: Could not initialize required directories.");
            System.out.println("Reason: " + friendlyReason(ex));
        }
    }

    private void promptForUserNameIfMissing() {
        String current = config.getUserName();
        if (current != null && !current.isBlank()) {
            return;
        }

        String name = readLine("Enter your name (optional, press Enter to skip): ");
        if (name == null) {
            return;
        }

        config.setUserName(name.trim());
    }

    private String readLine(String prompt) {
        try {
            if (!prompt.isEmpty()) {
                System.out.print(prompt);
            }
            return consoleReader.readLine();
        } catch (EOFException ex) {
            return null;
        } catch (IOException ex) {
            System.out.println("Error: Could not read input.");
            System.out.println("Reason: " + friendlyReason(ex));
            return null;
        }
    }

    private int readInt(String prompt) {
        while (true) {
            String input = readLine(prompt);
            if (input == null) {
                return 0;
            }

            String trimmed = input.trim();
            if (trimmed.isEmpty()) {
                System.out.println("Please enter a number.");
                continue;
            }

            try {
                return Integer.parseInt(trimmed);
            } catch (NumberFormatException ex) {
                System.out.println("Invalid number. Please try again.");
            }
        }
    }

    private DiaryConfig loadConfig() {
        Path configPath = Paths.get(CONFIG_FILE_NAME);
        if (!Files.exists(configPath)) {
            return new DiaryConfig();
        }

        try (ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(configPath, StandardOpenOption.READ))) {
            Object obj = ois.readObject();
            if (obj instanceof DiaryConfig) {
                return (DiaryConfig) obj;
            }
            return new DiaryConfig();
        } catch (IOException | SecurityException ex) {
            System.out.println("Warning: Could not load config file. Using defaults.");
            System.out.println("Reason: " + friendlyReason(ex));
            return new DiaryConfig();
        } catch (ClassNotFoundException ex) {
            System.out.println("Warning: Config file format is not recognized. Using defaults.");
            return new DiaryConfig();
        }
    }

    private void saveConfigQuietly() {
        try {
            saveConfig();
        } catch (IOException | SecurityException ex) {
            System.out.println("Warning: Could not save config.");
            System.out.println("Reason: " + friendlyReason(ex));
        }
    }

    private void saveConfig() throws IOException {
        Path configPath = Paths.get(CONFIG_FILE_NAME);

        // Keep paths relative
        config.setEntriesDirectory(entriesDir.toString());
        config.setBackupsDirectory(backupsDir.toString());

        try (ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(configPath,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE))) {
            oos.writeObject(config);
            oos.flush();
        }
    }

    private void printFriendlyError(String message, Exception ex) {
        System.out.println("Error: " + message);
        System.out.println("Reason: " + friendlyReason(ex));
        System.out.println("Returning to main menu...");
    }

    private String friendlyReason(Exception ex) {
        if (ex instanceof SecurityException) {
            return "Access denied.";
        }
        if (ex instanceof NoSuchFileException) {
            return "File not found.";
        }
        String msg = ex.getMessage();
        if (msg == null || msg.isBlank()) {
            return ex.getClass().getSimpleName();
        }
        return msg;
    }

    private String nullToDefault(String value, String defaultValue) {
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        return value;
    }

    private String buildSnippet(String line) {
        String trimmed = line.trim();
        if (trimmed.length() <= 80) {
            return trimmed;
        }
        return trimmed.substring(0, 77) + "...";
    }

    private static final class SearchResult {
        private final Path path;
        private final String snippet;

        private SearchResult(Path path, String snippet) {
            this.path = path;
            this.snippet = snippet;
        }
    }
}
