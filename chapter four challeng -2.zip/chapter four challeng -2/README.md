# Personal Diary Manager (Chapter 4 Challenge)

A production-style Java command-line application for managing personal diary entries using **`java.nio.file.Files`**, **`BufferedReader/BufferedWriter`**, timestamp-based filenames, keyword search, and bonus backup/serialization features.

## Features

- Write new diary entries (multi-line input)
- Read previous entries (numbered list)
- Search entries (case-insensitive, supports multiple keywords)
- Automatically creates required directories (`entries/`, `backups/`)
- Graceful error handling (no stack traces shown to the user)

### Bonus Features Implemented

- ZIP backup of all entries (`backups/diary_backup_YYYY_MM_dd.zip`)
- Object serialization for settings (`diary_config.ser`)

## Project Structure

```
DiaryManager/
├── src/
│   └── main/
│       └── java/
│           └── com/
│               └── diarymanager/
│                   ├── DiaryManager.java
│                   └── DiaryConfig.java
├── entries/              (auto-created)
├── backups/              (auto-created)
├── diary_config.ser      (auto-created on exit)
└── README.md
```

## How to Run (Windows / Command Line)

From the project root directory:

1. Compile:

```bash
javac -d out src/main/java/com/diarymanager/*.java
```

2. Run:

```bash
java -cp out com.diarymanager.DiaryManager
```

## Usage Examples

### Menu

```
================================
    PERSONAL DIARY MANAGER
================================
1. Write New Entry
2. Read Previous Entry
3. Search Entries
4. Create Backup (Bonus)
5. Exit
Choose an option (1-5):
```

### Writing Entries

- Type multiple lines.
- Finish by entering an empty line or `::end`.

Entries are saved as:

- `entries/diary_YYYY_MM_dd_HH_mm_ss.txt`

### Reading Entries

- The app lists entries in `entries/`.
- Choose a number to read or `0` to cancel.

### Searching

- Enter one or more keywords (separated by spaces).
- A file is a match only if **all** keywords are found somewhere in that entry.

### Backup ZIP

- Creates a ZIP file in `backups/` like:

```
backups/diary_backup_2026_01_02.zip
```

## DESIGN CHOICES

### Why `java.nio.file` (`Files`, `Path`) instead of `java.io.File`

- `Files` + `Path` provides modern, safer APIs with better exception handling and more flexible I/O operations.
- It integrates cleanly with try-with-resources and stream-based directory listing.

### Timestamp Format Rationale

- The assignment requires `yyyy_MM_dd_HH_mm_ss`.
- This format is sortable (lexicographically) and works well as a filename.

### Exception Handling Strategy

- All file operations are wrapped in:
  - try-with-resources for streams/readers/writers
  - `catch (IOException | SecurityException ...)` blocks
- The program prints **user-friendly messages** and returns to the main menu instead of crashing.

### Bonus Feature Implementation

- **Serialization**: `DiaryConfig` is saved to `diary_config.ser` on exit and loaded on startup.
- **ZIP backup**: Uses `ZipOutputStream` and `Files.copy(...)` to add each entry file into a ZIP archive.

## Dependencies

- None (pure Java, standard library only)
