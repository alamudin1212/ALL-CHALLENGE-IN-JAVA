# Chapter1_Challenge_1_2 — Lottery Number Analyzer

### 🎯 Description
This program analyzes a list of winning lottery numbers stored as strings in the format "XX-XX-XX-XX-XX".  
For each ticket, it removes the dashes, converts the digits into integers, and calculates both the sum and average of all digits.  
Finally, it identifies the ticket with the highest average digit value.
