# Personal Diary Manager - JavaFX GUI Version

## Overview

A professional, feature-rich diary application built with JavaFX that demonstrates advanced GUI programming, file I/O operations, and modern software design principles. This is the enhanced GUI version of the command-line diary manager, created as a Chapter 4 Challenge assignment.

## Features

### Core Functionality
- **Rich Text Editor**: Full-featured HTML editor with formatting options (bold, italic, underline, fonts, colors)
- **Visual Entry Browser**: ListView with entry previews, sorting, and filtering
- **Real-time Search**: Advanced search with filters, regex support, and live results
- **Theme System**: Professional Light and Dark themes with smooth transitions
- **Background Operations**: All file I/O operations run in background threads with progress indicators

### Technical Features
- **Concurrency**: Uses JavaFX Task/Service for non-blocking file operations
- **Modern UI/UX**: Professional interface with responsive design
- **File Management**: Enhanced Files API with automatic directory creation
- **Error Handling**: User-friendly dialogs and graceful error recovery
- **Auto-save**: Automatic saving with configurable intervals
- **Keyboard Shortcuts**: Ctrl+N (New), Ctrl+F (Search), Ctrl+S (Save), Ctrl+T (Theme)

### Enhanced Features
- **Entry Organization**: Tags, favorites, and statistics
- **Import/Export**: Support for external text files
- **Search Filters**: Date ranges, word counts, tag filtering
- **Entry Statistics**: Word counts, character counts, storage usage
- **Professional Styling**: Modern CSS with hover effects and transitions

## Project Structure

```
DiaryManagerGUI/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── diarygui/
│       │           ├── Main.java                    # Application entry point
│       │           ├── controllers/
│       │           │   ├── MainController.java       # Main interface controller
│       │           │   ├── EditorController.java      # Rich text editor
│       │           │   └── SearchController.java      # Search interface
│       │           ├── models/
│       │           │   ├── DiaryEntry.java           # Entry data model
│       │           │   └── DiaryModel.java           # Application state
│       │           ├── services/
│       │           │   ├── FileService.java          # Background file operations
│       │           │   ├── SearchService.java        # Search functionality
│       │           │   └── ThemeService.java         # Theme management
│       │           └── tasks/
│       │               ├── LoadEntriesTask.java      # Background loading
│       │               ├── SaveEntryTask.java        # Background saving
│       │               ├── DeleteEntryTask.java      # Background deletion
│       │               └── SearchTask.java           # Background search
│       └── resources/
│           └── com/
│               └── diarygui/
│                   ├── main.fxml                    # Main interface layout
│                   ├── common.css                   # Shared styles
│                   ├── light-theme.css              # Light theme
│                   └── dark-theme.css               # Dark theme
├── entries/                                      # Auto-created diary entries
├── README.md                                     # This documentation
└── diary-settings.properties                     # User preferences
```

## Design Rationale

### GUI Design Choices
- **BorderPane Layout**: Provides clear separation of navigation (sidebar) and content (main area)
- **Modern Controls**: Uses JavaFX 17 controls with CSS styling for professional appearance
- **Responsive Design**: Interface adapts to window resizing with proper constraints
- **Visual Hierarchy**: Clear typography and spacing for intuitive navigation

### Architecture Patterns
- **MVC Pattern**: Clear separation between Models, Views (FXML), and Controllers
- **Service Layer**: Business logic separated into service classes
- **Background Tasks**: All I/O operations use JavaFX Task for non-blocking UI
- **Observer Pattern**: UI components respond to model changes through listeners

### File I/O Implementation
- **Files API (java.nio.file)**: Modern file handling with better error management
- **Timestamped Files**: Entries saved as `diary_YYYY_MM_dd_HH_mm_ss.txt`
- **Metadata Storage**: Entry metadata stored in file headers for easy parsing
- **Concurrent Operations**: Multiple file operations can run simultaneously

### Concurrency Implementation
- **JavaFX Task**: All file operations run in background threads
- **Progress Indicators**: Visual feedback for long-running operations
- **Thread Safety**: Proper UI updates using Platform.runLater()
- **Auto-save Timer**: Background timer for automatic saving

## Theme System

### Light Theme
- Clean, professional appearance with high contrast
- Optimized for daytime use and bright environments
- Blue accent colors (#1976D2) with neutral grays

### Dark Theme
- Easy on the eyes for low-light environments
- Purple accent colors (#BB86FC) with dark backgrounds
- Reduced eye strain for extended use sessions

### Theme Features
- **Instant Switching**: Themes change immediately without restart
- **Persistent Settings**: Theme preference saved between sessions
- **Smooth Transitions**: CSS transitions for theme changes
- **Complete Coverage**: All UI elements properly themed

## Search System

### Search Capabilities
- **Real-time Search**: Results update as you type (3+ characters)
- **Advanced Filters**: Date ranges, word counts, tag filtering
- **Regex Support**: Pattern matching for power users
- **Context Display**: Search results with surrounding text context

### Search Features
- **Multiple Criteria**: Combine text, date, and tag filters
- **Case Sensitivity**: Optional case-sensitive searching
- **Whole Word Matching**: Optional exact word matching
- **Result Highlighting**: Clear indication of match locations

## How to Run

### Prerequisites
- Java Development Kit (JDK) 17 or higher
- JavaFX 17 or higher
- Modern IDE (IntelliJ IDEA, Eclipse, or VS Code)

### Compilation and Execution

#### Using Command Line
```bash
# Compile the application
javac --module-path /path/to/javafx/lib --add-modules javafx.controls,javafx.fxml \
      -d build/classes src/main/java/com/diarygui/*.java \
      src/main/java/com/diarygui/controllers/*.java \
      src/main/java/com/diarygui/models/*.java \
      src/main/java/com/diarygui/services/*.java \
      src/main/java/com/diarygui/tasks/*.java

# Run the application
java --module-path /path/to/javafx/lib --add-modules javafx.controls,javafx.fxml \
     -cp build/classes com.diarygui.Main
```

#### Using IDE
1. Import the project as a Maven/Gradle project
2. Add JavaFX dependencies to the classpath
3. Set the main class to `com.diarygui.Main`
4. Run the application

#### Using Maven (if pom.xml is added)
```bash
mvn clean compile
mvn javafx:run
```

## File Format

### Entry File Structure
Each diary entry is saved as a plain text file with metadata headers:

```
Title: My Diary Entry
Created: 2024-01-15T10:30:00
Modified: 2024-01-15T11:45:00
Tags: personal, work, important
Favorite: false
---
This is the actual content of the diary entry with rich text formatting.
```

### File Naming Convention
- Format: `diary_YYYY_MM_dd_HH_mm_ss.txt`
- Example: `diary_2024_01_15_10_30_00.txt`
- Ensures chronological sorting and unique filenames

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+N | New Entry |
| Ctrl+F | Search |
| Ctrl+S | Save Current Entry |
| Ctrl+T | Toggle Theme |
| Ctrl+Q | Exit Application |
| Ctrl+Z | Undo |
| Ctrl+Y | Redo |
| Ctrl+C | Copy |
| Ctrl+V | Paste |
| Ctrl+A | Select All |
| Escape | Close Dialog |

## Performance Considerations

### Optimization Features
- **Lazy Loading**: Entries loaded in background batches
- **Efficient Search**: Indexed search with result caching
- **Memory Management**: Proper cleanup of resources and timers
- **UI Responsiveness**: All heavy operations run in background threads

### Scalability
- **Entry Capacity**: Designed to handle 1000+ entries without performance degradation
- **Search Performance**: Optimized search algorithms with early termination
- **Memory Usage**: Efficient data structures with minimal memory footprint

## Error Handling

### User-Friendly Errors
- **File I/O Errors**: Clear messages with suggested solutions
- **Validation Errors**: Input validation with helpful feedback
- **Network Errors**: Graceful handling of external file operations
- **Recovery Options**: Automatic retry and manual recovery options

### Logging
- **Error Logging**: Detailed error information for debugging
- **Performance Metrics**: Operation timing and resource usage
- **User Actions**: Optional logging of user interactions

## Future Enhancements

### Planned Features
- **Cloud Sync**: Integration with cloud storage services
- **Export Options**: PDF, HTML, and Markdown export
- **Templates**: Pre-defined entry templates
- **Attachments**: Support for images and files
- **Collaboration**: Multi-user diary sharing

### Technical Improvements
- **Database Backend**: Optional database storage for large datasets
- **Plugin System**: Extensible architecture for plugins
- **Mobile Version**: Cross-platform mobile application
- **Web Interface**: Browser-based diary management

## Troubleshooting

### Common Issues

#### Application Won't Start
- Check Java version (requires JDK 17+)
- Verify JavaFX is properly configured
- Ensure all dependencies are on classpath

#### File I/O Errors
- Check write permissions in application directory
- Verify sufficient disk space
- Ensure entries directory is not corrupted

#### Theme Issues
- Clear CSS cache if themes don't apply
- Restart application after theme changes
- Check for CSS syntax errors

#### Performance Issues
- Increase JVM memory allocation: `-Xmx2g`
- Check for large entry files (>1MB)
- Verify background tasks are completing

### Debug Mode
Enable debug logging by setting the system property:
```bash
-Ddiary.debug=true
```

## Contributing

### Code Style
- Follow Java naming conventions
- Use meaningful variable names
- Add Javadoc comments for public methods
- Keep methods under 50 lines when possible

### Testing
- Test all file I/O operations
- Verify UI responsiveness under load
- Test theme switching functionality
- Validate search accuracy

## License

This project is created for educational purposes as part of a university assignment. Please respect academic integrity when using or referencing this code.

## Acknowledgments

- JavaFX Development Team for the excellent GUI framework
- University instructors for the assignment requirements
- Open-source community for inspiration and best practices

---

**Version**: 1.0.0  
**Last Updated**: January 2024  
**Assignment**: Chapter 4 Challenge - Personal Diary Manager  
**Technologies**: JavaFX 17, Java 17, CSS, FXML
