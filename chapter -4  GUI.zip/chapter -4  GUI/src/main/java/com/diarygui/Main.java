package com.diarygui;

import com.diarygui.controllers.MainController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    private MainController mainController;

    @Override
    public void start(Stage primaryStage) throws IOException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/diarygui/main.fxml"));
            Parent root = loader.load();
            
            mainController = loader.getController();
            mainController.setPrimaryStage(primaryStage);
            
            Scene scene = new Scene(root, 1200, 800);
            
            scene.getStylesheets().add(getClass().getResource("/com/diarygui/common.css").toExternalForm());
            scene.getStylesheets().add(getClass().getResource(mainController.getThemeService().getThemeStylesheet()).toExternalForm());
            
            primaryStage.setTitle("Personal Diary Manager - JavaFX GUI Version");
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(800);
            primaryStage.setMinHeight(600);
            
            primaryStage.setOnCloseRequest(event -> {
                if (mainController != null) {
                    mainController.cleanup();
                }
            });
            
            primaryStage.show();
            
        } catch (Exception e) {
            showError("Startup Error", "Failed to start the application: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showError(String title, String message) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
            javafx.scene.control.Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
