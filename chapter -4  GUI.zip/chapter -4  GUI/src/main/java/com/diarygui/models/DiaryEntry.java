package com.diarygui.models;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DiaryEntry {
    private String id;
    private String title;
    private String content;
    private LocalDateTime createdAt;
    private LocalDateTime lastModified;
    private List<String> tags;
    private boolean isFavorite;
    private String fileName;

    public DiaryEntry() {
        this.id = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
        this.lastModified = LocalDateTime.now();
        this.tags = new ArrayList<>();
        this.isFavorite = false;
        this.title = "";
        this.content = "";
        generateFileName();
    }

    public DiaryEntry(String title, String content) {
        this();
        this.title = title;
        this.content = content;
        this.lastModified = LocalDateTime.now();
    }

    private void generateFileName() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss");
        this.fileName = "diary_" + createdAt.format(formatter) + ".txt";
    }

    public String getPreview() {
        if (content == null || content.isEmpty()) {
            return "No content";
        }
        
        String cleanContent = content.replaceAll("<[^>]*>", "").trim();
        if (cleanContent.length() <= 100) {
            return cleanContent;
        }
        return cleanContent.substring(0, 97) + "...";
    }

    public String getFirstLine() {
        if (content == null || content.isEmpty()) {
            return "";
        }
        
        String cleanContent = content.replaceAll("<[^>]*>", "").trim();
        String[] lines = cleanContent.split("\n");
        return lines.length > 0 ? lines[0] : "";
    }

    public int getWordCount() {
        if (content == null || content.isEmpty()) {
            return 0;
        }
        String cleanContent = content.replaceAll("<[^>]*>", "").trim();
        return cleanContent.split("\\s+").length;
    }

    public int getCharacterCount() {
        if (content == null) {
            return 0;
        }
        return content.length();
    }

    public void updateContent(String newContent) {
        this.content = newContent;
        this.lastModified = LocalDateTime.now();
    }

    public void addTag(String tag) {
        if (tag != null && !tag.trim().isEmpty() && !tags.contains(tag.trim())) {
            tags.add(tag.trim());
        }
    }

    public void removeTag(String tag) {
        tags.remove(tag);
    }

    public boolean hasTag(String tag) {
        return tags.contains(tag);
    }

    @Override
    public String toString() {
        return "DiaryEntry{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", createdAt=" + createdAt +
                ", wordCount=" + getWordCount() +
                '}';
    }

    public String toFileContent() {
        StringBuilder sb = new StringBuilder();
        sb.append("Title: ").append(title).append("\n");
        sb.append("Created: ").append(createdAt).append("\n");
        sb.append("Modified: ").append(lastModified).append("\n");
        sb.append("Tags: ").append(String.join(", ", tags)).append("\n");
        sb.append("Favorite: ").append(isFavorite).append("\n");
        sb.append("---\n");
        sb.append(content);
        return sb.toString();
    }

    public static DiaryEntry fromFileContent(String fileContent, String fileName) {
        DiaryEntry entry = new DiaryEntry();
        entry.fileName = fileName;
        
        String[] parts = fileContent.split("---\n", 2);
        if (parts.length >= 2) {
            String metadata = parts[0];
            entry.content = parts[1];
            
            String[] lines = metadata.split("\n");
            for (String line : lines) {
                if (line.startsWith("Title: ")) {
                    entry.title = line.substring(7);
                } else if (line.startsWith("Created: ")) {
                    entry.createdAt = LocalDateTime.parse(line.substring(9));
                } else if (line.startsWith("Modified: ")) {
                    entry.lastModified = LocalDateTime.parse(line.substring(10));
                } else if (line.startsWith("Tags: ")) {
                    String tagsStr = line.substring(6);
                    if (!tagsStr.trim().isEmpty()) {
                        entry.tags = List.of(tagsStr.split(",\\s*"));
                    }
                } else if (line.startsWith("Favorite: ")) {
                    entry.isFavorite = Boolean.parseBoolean(line.substring(10));
                }
            }
        } else {
            entry.content = fileContent;
        }
        
        return entry;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { 
        this.title = title; 
        this.lastModified = LocalDateTime.now();
    }

    public String getContent() { return content; }
    public void setContent(String content) { 
        this.content = content; 
        this.lastModified = LocalDateTime.now();
    }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getLastModified() { return lastModified; }
    public void setLastModified(LocalDateTime lastModified) { this.lastModified = lastModified; }

    public List<String> getTags() { return new ArrayList<>(tags); }
    public void setTags(List<String> tags) { 
        this.tags = new ArrayList<>(tags != null ? tags : new ArrayList<>()); 
        this.lastModified = LocalDateTime.now();
    }

    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { 
        this.isFavorite = favorite; 
        this.lastModified = LocalDateTime.now();
    }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
}
