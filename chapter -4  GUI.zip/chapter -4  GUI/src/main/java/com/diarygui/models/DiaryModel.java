package com.diarygui.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DiaryModel {
    private List<DiaryEntry> entries;
    private DiaryEntry currentEntry;
    private String currentTheme;
    private boolean autoSaveEnabled;
    private int autoSaveInterval;

    public DiaryModel() {
        this.entries = new ArrayList<>();
        this.currentEntry = null;
        this.currentTheme = "light";
        this.autoSaveEnabled = true;
        this.autoSaveInterval = 30;
    }

    public void addEntry(DiaryEntry entry) {
        if (entry != null && !entries.contains(entry)) {
            entries.add(entry);
        }
    }

    public void removeEntry(DiaryEntry entry) {
        entries.remove(entry);
        if (currentEntry == entry) {
            currentEntry = null;
        }
    }

    public DiaryEntry getEntryById(String id) {
        return entries.stream()
                .filter(entry -> entry.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public DiaryEntry getEntryByFileName(String fileName) {
        return entries.stream()
                .filter(entry -> entry.getFileName().equals(fileName))
                .findFirst()
                .orElse(null);
    }

    public List<DiaryEntry> getAllEntries() {
        return new ArrayList<>(entries);
    }

    public List<DiaryEntry> getEntriesByTag(String tag) {
        return entries.stream()
                .filter(entry -> entry.hasTag(tag))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public List<DiaryEntry> getFavoriteEntries() {
        return entries.stream()
                .filter(DiaryEntry::isFavorite)
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public List<DiaryEntry> getTodayEntries() {
        return entries.stream()
                .filter(entry -> entry.getCreatedAt().toLocalDate().equals(java.time.LocalDate.now()))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public List<DiaryEntry> searchEntries(String query) {
        if (query == null || query.trim().isEmpty()) {
            return new ArrayList<>(entries);
        }
        
        String lowerQuery = query.toLowerCase();
        return entries.stream()
                .filter(entry -> 
                    entry.getTitle().toLowerCase().contains(lowerQuery) ||
                    entry.getContent().toLowerCase().contains(lowerQuery) ||
                    entry.getTags().stream().anyMatch(tag -> tag.toLowerCase().contains(lowerQuery)))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public void setCurrentEntry(DiaryEntry entry) {
        this.currentEntry = entry;
    }

    public DiaryEntry getCurrentEntry() {
        return currentEntry;
    }

    public void clearEntries() {
        entries.clear();
        currentEntry = null;
    }

    public int getEntryCount() {
        return entries.size();
    }

    public int getTotalWordCount() {
        return entries.stream()
                .mapToInt(DiaryEntry::getWordCount)
                .sum();
    }

    public List<String> getAllTags() {
        return entries.stream()
                .flatMap(entry -> entry.getTags().stream())
                .distinct()
                .sorted()
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public String getCurrentTheme() {
        return currentTheme;
    }

    public void setCurrentTheme(String currentTheme) {
        this.currentTheme = currentTheme;
    }

    public boolean isAutoSaveEnabled() {
        return autoSaveEnabled;
    }

    public void setAutoSaveEnabled(boolean autoSaveEnabled) {
        this.autoSaveEnabled = autoSaveEnabled;
    }

    public int getAutoSaveInterval() {
        return autoSaveInterval;
    }

    public void setAutoSaveInterval(int autoSaveInterval) {
        this.autoSaveInterval = autoSaveInterval;
    }
}
