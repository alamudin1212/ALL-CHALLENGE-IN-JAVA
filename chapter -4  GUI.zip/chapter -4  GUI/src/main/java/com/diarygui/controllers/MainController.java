package com.diarygui.controllers;

import com.diarygui.models.DiaryEntry;
import com.diarygui.models.DiaryModel;
import com.diarygui.services.*;
import com.diarygui.tasks.*;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Timer;
import javafx.util.TimerTask;

import java.time.LocalDate;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainController {
    @FXML private BorderPane mainPane;
    @FXML private VBox sidebar;
    @FXML private ListView<DiaryEntry> entriesListView;
    @FXML private Button newEntryButton;
    @FXML private Button searchButton;
    @FXML private Button themeToggleButton;
    @FXML private ProgressBar progressBar;
    @FXML private Label statusLabel;
    @FXML private Label entryCountLabel;
    @FXML private Label wordCountLabel;
    @FXML private MenuItem newEntryMenuItem;
    @FXML private MenuItem searchMenuItem;
    @FXML private MenuItem themeMenuItem;
    @FXML private MenuItem aboutMenuItem;
    @FXML private MenuItem exitMenuItem;

    private DiaryModel diaryModel;
    private FileService fileService;
    private SearchService searchService;
    private ThemeService themeService;
    private EditorController editorController;
    private SearchController searchController;
    private Stage primaryStage;
    private Timer autoSaveTimer;
    private ObservableList<DiaryEntry> entriesObservableList;

    @FXML
    public void initialize() {
        diaryModel = new DiaryModel();
        fileService = new FileService(diaryModel);
        searchService = new SearchService(diaryModel);
        themeService = new ThemeService();
        
        entriesObservableList = FXCollections.observableArrayList();
        entriesListView.setItems(entriesObservableList);
        
        setupListView();
        setupEventHandlers();
        setupKeyboardShortcuts();
        loadEntries();
        updateStatistics();
        startAutoSaveTimer();
        
        Platform.runLater(() -> applyTheme());
    }

    private void setupListView() {
        entriesListView.setCellFactory(param -> new ListCell<DiaryEntry>() {
            @Override
            protected void updateItem(DiaryEntry entry, boolean empty) {
                super.updateItem(entry, empty);
                if (empty || entry == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    VBox content = new VBox(5);
                    content.getStyleClass().add("entry-cell");
                    
                    Label titleLabel = new Label(entry.getTitle());
                    titleLabel.getStyleClass().add("entry-title");
                    
                    Label dateLabel = new Label(entry.getCreatedAt().toString());
                    dateLabel.getStyleClass().add("entry-date");
                    
                    Label previewLabel = new Label(entry.getPreview());
                    previewLabel.getStyleClass().add("entry-preview");
                    previewLabel.setWrapText(true);
                    
                    content.getChildren().addAll(titleLabel, dateLabel, previewLabel);
                    setGraphic(content);
                }
            }
        });
        
        entriesListView.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                diaryModel.setCurrentEntry(newVal);
                showEntryEditor(newVal);
            }
        });
    }

    private void setupEventHandlers() {
        newEntryButton.setOnAction(this::handleNewEntry);
        searchButton.setOnAction(this::handleSearch);
        themeToggleButton.setOnAction(this::handleThemeToggle);
        
        newEntryMenuItem.setOnAction(this::handleNewEntry);
        searchMenuItem.setOnAction(this::handleSearch);
        themeMenuItem.setOnAction(this::handleThemeToggle);
        aboutMenuItem.setOnAction(this::handleAbout);
        exitMenuItem.setOnAction(this::handleExit);
    }

    private void setupKeyboardShortcuts() {
        mainPane.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.isControlDown()) {
                switch (event.getCode()) {
                    case N -> handleNewEntry(null);
                    case F -> handleSearch(null);
                    case S -> saveCurrentEntry();
                    case T -> handleThemeToggle(null);
                }
            }
        });
    }

    private void loadEntries() {
        LoadEntriesTask task = new LoadEntriesTask(fileService, diaryModel);
        
        task.messageProperty().addListener((obs, oldMsg, newMsg) -> 
            Platform.runLater(() -> statusLabel.setText(newMsg)));
        
        task.progressProperty().addListener((obs, oldProgress, newProgress) -> 
            Platform.runLater(() -> progressBar.setProgress(newProgress.doubleValue())));
        
        task.setOnSucceeded(event -> {
            Platform.runLater(() -> {
                entriesObservableList.setAll(diaryModel.getAllEntries());
                progressBar.setVisible(false);
                statusLabel.setText("Ready");
                updateStatistics();
            });
        });
        
        task.setOnFailed(event -> {
            Platform.runLater(() -> {
                progressBar.setVisible(false);
                statusLabel.setText("Failed to load entries");
                showError("Load Error", "Failed to load diary entries: " + 
                    task.getException().getMessage());
            });
        });
        
        progressBar.setVisible(true);
        Thread thread = new Thread(task);
        thread.setDaemon(true);
        thread.start();
    }

    private void showEntryEditor(DiaryEntry entry) {
        try {
            if (editorController == null) {
                editorController = new EditorController(diaryModel, fileService, themeService);
            }
            editorController.showEntry(entry, primaryStage);
        } catch (Exception e) {
            showError("Editor Error", "Failed to open entry editor: " + e.getMessage());
        }
    }

    private void showSearchPanel() {
        try {
            if (searchController == null) {
                searchController = new SearchController(diaryModel, searchService, themeService);
            }
            searchController.showSearchDialog(primaryStage);
        } catch (Exception e) {
            showError("Search Error", "Failed to open search: " + e.getMessage());
        }
    }

    @FXML
    private void handleNewEntry(ActionEvent event) {
        DiaryEntry newEntry = new DiaryEntry();
        newEntry.setTitle("New Entry - " + LocalDate.now());
        diaryModel.addEntry(newEntry);
        entriesObservableList.add(0, newEntry);
        entriesListView.getSelectionModel().select(0);
        showEntryEditor(newEntry);
        updateStatistics();
    }

    @FXML
    private void handleSearch(ActionEvent event) {
        showSearchPanel();
    }

    @FXML
    private void handleThemeToggle(ActionEvent event) {
        themeService.toggleTheme();
        applyTheme();
    }

    @FXML
    private void handleAbout(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About Diary Manager");
        alert.setHeaderText("Personal Diary Manager - JavaFX GUI Version");
        alert.setContentText("Chapter 4 Challenge Assignment\n\n" +
            "A modern diary application with:\n" +
            "• Rich text editing\n" +
            "• Real-time search\n" +
            "• Theme support\n" +
            "• Background file operations\n" +
            "• Professional UI/UX\n\n" +
            "Created for University Assignment");
        alert.showAndWait();
    }

    @FXML
    private void handleExit(ActionEvent event) {
        if (autoSaveTimer != null) {
            autoSaveTimer.cancel();
        }
        Platform.exit();
    }

    private void saveCurrentEntry() {
        if (editorController != null && editorController.hasUnsavedChanges()) {
            editorController.saveEntry();
        }
    }

    private void applyTheme() {
        if (primaryStage != null && primaryStage.getScene() != null) {
            var scene = primaryStage.getScene();
            scene.getStylesheets().clear();
            scene.getStylesheets().add(getClass().getResource(themeService.getCommonStylesheet()).toExternalForm());
            scene.getStylesheets().add(getClass().getResource(themeService.getThemeStylesheet()).toExternalForm());
            
            String icon = themeService.isDarkTheme() ? "🌙" : "☀️";
            if (themeToggleButton != null) {
                themeToggleButton.setText(icon + " Theme");
            }
        }
    }

    private void updateStatistics() {
        Platform.runLater(() -> {
            entryCountLabel.setText("Entries: " + diaryModel.getEntryCount());
            wordCountLabel.setText("Words: " + diaryModel.getTotalWordCount());
        });
    }

    private void startAutoSaveTimer() {
        if (autoSaveTimer != null) {
            autoSaveTimer.cancel();
        }
        
        autoSaveTimer = new Timer("AutoSave", true);
        autoSaveTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (editorController != null && editorController.hasUnsavedChanges()) {
                    Platform.runLater(() -> {
                        editorController.autoSave();
                        statusLabel.setText("Auto-saved");
                    });
                }
            }
        }, 30000, 30000); // 30 seconds
    }

    private void showError(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
        applyTheme();
    }

    public void refreshEntriesList() {
        entriesObservableList.setAll(diaryModel.getAllEntries());
        updateStatistics();
    }

    public DiaryModel getDiaryModel() {
        return diaryModel;
    }

    public FileService getFileService() {
        return fileService;
    }

    public void cleanup() {
        if (autoSaveTimer != null) {
            autoSaveTimer.cancel();
        }
        if (editorController != null) {
            editorController.cleanup();
        }
    }

    public ThemeService getThemeService() {
        return themeService;
    }
}
