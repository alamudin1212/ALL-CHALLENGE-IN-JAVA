package com.diarygui.controllers;

import com.diarygui.models.DiaryEntry;
import com.diarygui.models.DiaryModel;
import com.diarygui.services.FileService;
import com.diarygui.services.ThemeService;
import com.diarygui.tasks.SaveEntryTask;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.web.HTMLEditor;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.Timer;
import java.util.TimerTask;

public class EditorController {
    private final DiaryModel diaryModel;
    private final FileService fileService;
    private final ThemeService themeService;
    
    private Stage editorStage;
    private HTMLEditor htmlEditor;
    private TextField titleField;
    private Label wordCountLabel;
    private Label charCountLabel;
    private Label lastSavedLabel;
    private Button saveButton;
    private Button closeButton;
    private ProgressBar progressBar;
    private Label statusLabel;
    
    private DiaryEntry currentEntry;
    private String lastSavedContent;
    private Timer autoSaveTimer;
    private boolean hasUnsavedChanges;

    public EditorController(DiaryModel diaryModel, FileService fileService, ThemeService themeService) {
        this.diaryModel = diaryModel;
        this.fileService = fileService;
        this.themeService = themeService;
    }

    public void showEntry(DiaryEntry entry, Stage ownerStage) {
        this.currentEntry = entry;
        this.lastSavedContent = entry.getContent();
        
        if (editorStage == null) {
            createEditorStage();
        }
        
        loadEntryData();
        editorStage.initOwner(ownerStage);
        editorStage.show();
        editorStage.toFront();
        
        htmlEditor.requestFocus();
    }

    private void createEditorStage() {
        editorStage = new Stage();
        editorStage.setTitle("Diary Entry Editor");
        editorStage.initModality(Modality.APPLICATION_MODAL);
        editorStage.setWidth(800);
        editorStage.setHeight(600);
        
        VBox root = new VBox(10);
        root.getStyleClass().add("editor-root");
        root.setPadding(new Insets(15));
        
        HBox titleBox = new HBox(10);
        titleBox.setAlignment(Pos.CENTER_LEFT);
        
        Label titleLabel = new Label("Title:");
        titleLabel.getStyleClass().add("editor-label");
        
        titleField = new TextField();
        titleField.getStyleClass().add("editor-title-field");
        titleField.setPromptText("Enter entry title...");
        HBox.setHgrow(titleField, Priority.ALWAYS);
        
        titleBox.getChildren().addAll(titleLabel, titleField);
        
        HBox statsBox = new HBox(20);
        statsBox.setAlignment(Pos.CENTER_LEFT);
        
        wordCountLabel = new Label("Words: 0");
        wordCountLabel.getStyleClass().add("stats-label");
        
        charCountLabel = new Label("Characters: 0");
        charCountLabel.getStyleClass().add("stats-label");
        
        lastSavedLabel = new Label("Not saved");
        lastSavedLabel.getStyleClass().add("last-saved-label");
        HBox.setHgrow(lastSavedLabel, Priority.ALWAYS);
        lastSavedLabel.setAlignment(Pos.CENTER_RIGHT);
        
        statsBox.getChildren().addAll(wordCountLabel, charCountLabel, lastSavedLabel);
        
        htmlEditor = new HTMLEditor();
        htmlEditor.getStyleClass().add("html-editor");
        htmlEditor.setPrefHeight(400);
        
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        
        saveButton = new Button("Save");
        saveButton.getStyleClass().add("primary-button");
        saveButton.setOnAction(e -> saveEntry());
        
        Button cancelButton = new Button("Cancel");
        cancelButton.getStyleClass().add("secondary-button");
        cancelButton.setOnAction(e -> closeEditor());
        
        closeButton = new Button("Close");
        closeButton.getStyleClass().add("secondary-button");
        closeButton.setOnAction(e -> closeEditor());
        
        buttonBox.getChildren().addAll(saveButton, cancelButton, closeButton);
        
        HBox progressBox = new HBox(10);
        progressBox.setAlignment(Pos.CENTER_LEFT);
        
        progressBar = new ProgressBar();
        progressBar.setPrefWidth(200);
        progressBar.setVisible(false);
        
        statusLabel = new Label("Ready");
        statusLabel.getStyleClass().add("status-label");
        
        progressBox.getChildren().addAll(progressBar, statusLabel);
        
        root.getChildren().addAll(titleBox, statsBox, htmlEditor, buttonBox, progressBox);
        
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource(themeService.getCommonStylesheet()).toExternalForm());
        scene.getStylesheets().add(getClass().getResource(themeService.getThemeStylesheet()).toExternalForm());
        
        editorStage.setScene(scene);
        
        setupEventHandlers();
        setupKeyboardShortcuts();
        startAutoSaveTimer();
        
        editorStage.setOnCloseRequest(e -> {
            if (hasUnsavedChanges) {
                e.consume();
                showUnsavedChangesDialog();
            }
        });
    }

    private void setupEventHandlers() {
        titleField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (currentEntry != null) {
                currentEntry.setTitle(newVal);
                checkForUnsavedChanges();
                updateLastSavedLabel();
            }
        });
        
        htmlEditor.getHtmlTextProperty().addListener((obs, oldVal, newVal) -> {
            if (currentEntry != null) {
                currentEntry.setContent(newVal);
                updateStatistics();
                checkForUnsavedChanges();
                updateLastSavedLabel();
            }
        });
        
        titleField.focusedProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal) {
                titleField.setText(titleField.getText().trim());
            }
        });
    }

    private void setupKeyboardShortcuts() {
        editorStage.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.isControlDown()) {
                switch (event.getCode()) {
                    case S -> {
                        event.consume();
                        saveEntry();
                    }
                    case W -> {
                        event.consume();
                        closeEditor();
                    }
                }
            } else if (event.getCode() == KeyCode.ESCAPE) {
                event.consume();
                closeEditor();
            }
        });
    }

    private void loadEntryData() {
        if (currentEntry != null) {
            titleField.setText(currentEntry.getTitle());
            htmlEditor.setHtmlText(currentEntry.getContent());
            updateStatistics();
            updateLastSavedLabel();
            hasUnsavedChanges = false;
            updateWindowTitle();
        }
    }

    private void updateStatistics() {
        if (currentEntry != null) {
            Platform.runLater(() -> {
                wordCountLabel.setText("Words: " + currentEntry.getWordCount());
                charCountLabel.setText("Characters: " + currentEntry.getCharacterCount());
            });
        }
    }

    private void updateLastSavedLabel() {
        if (hasUnsavedChanges) {
            lastSavedLabel.setText("Unsaved changes");
            lastSavedLabel.getStyleClass().add("unsaved");
        } else {
            lastSavedLabel.setText("Saved");
            lastSavedLabel.getStyleClass().remove("unsaved");
        }
    }

    private void checkForUnsavedChanges() {
        String currentContent = currentEntry.getContent();
        boolean newHasChanges = !currentContent.equals(lastSavedContent);
        
        if (newHasChanges != hasUnsavedChanges) {
            hasUnsavedChanges = newHasChanges;
            updateWindowTitle();
        }
    }

    private void updateWindowTitle() {
        String title = "Diary Entry Editor";
        if (currentEntry != null) {
            title += " - " + currentEntry.getTitle();
            if (hasUnsavedChanges) {
                title += " *";
            }
        }
        editorStage.setTitle(title);
    }

    public void saveEntry() {
        if (currentEntry == null) return;
        
        SaveEntryTask task = new SaveEntryTask(fileService, currentEntry);
        
        task.messageProperty().addListener((obs, oldMsg, newMsg) -> 
            Platform.runLater(() -> statusLabel.setText(newMsg)));
        
        task.progressProperty().addListener((obs, oldProgress, newProgress) -> 
            Platform.runLater(() -> progressBar.setProgress(newProgress.doubleValue())));
        
        task.setOnSucceeded(event -> {
            Platform.runLater(() -> {
                Boolean success = task.getValue();
                if (success) {
                    lastSavedContent = currentEntry.getContent();
                    hasUnsavedChanges = false;
                    updateLastSavedLabel();
                    updateWindowTitle();
                    statusLabel.setText("Entry saved successfully");
                } else {
                    statusLabel.setText("Failed to save entry");
                }
                progressBar.setVisible(false);
                saveButton.setDisable(false);
            });
        });
        
        task.setOnFailed(event -> {
            Platform.runLater(() -> {
                statusLabel.setText("Save failed: " + task.getException().getMessage());
                progressBar.setVisible(false);
                saveButton.setDisable(false);
                showError("Save Error", "Failed to save entry: " + task.getException().getMessage());
            });
        });
        
        progressBar.setVisible(true);
        saveButton.setDisable(true);
        statusLabel.setText("Saving...");
        
        Thread thread = new Thread(task);
        thread.setDaemon(true);
        thread.start();
    }

    public void autoSave() {
        if (hasUnsavedChanges && currentEntry != null) {
            SaveEntryTask task = new SaveEntryTask(fileService, currentEntry);
            
            task.setOnSucceeded(event -> {
                Platform.runLater(() -> {
                    Boolean success = task.getValue();
                    if (success) {
                        lastSavedContent = currentEntry.getContent();
                        hasUnsavedChanges = false;
                        updateLastSavedLabel();
                        updateWindowTitle();
                    }
                });
            });
            
            Thread thread = new Thread(task);
            thread.setDaemon(true);
            thread.start();
        }
    }

    private void closeEditor() {
        if (hasUnsavedChanges) {
            showUnsavedChangesDialog();
        } else {
            editorStage.hide();
        }
    }

    private void showUnsavedChangesDialog() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Unsaved Changes");
        alert.setHeaderText("You have unsaved changes");
        alert.setContentText("Do you want to save your changes before closing?");
        
        ButtonType saveButton = new ButtonType("Save");
        ButtonType dontSaveButton = new ButtonType("Don't Save");
        ButtonType cancelButton = new ButtonType("Cancel");
        
        alert.getButtonTypes().setAll(saveButton, dontSaveButton, cancelButton);
        
        alert.showAndWait().ifPresent(result -> {
            if (result == saveButton) {
                saveEntry();
                if (!hasUnsavedChanges) {
                    editorStage.hide();
                }
            } else if (result == dontSaveButton) {
                editorStage.hide();
            }
        });
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void startAutoSaveTimer() {
        if (autoSaveTimer != null) {
            autoSaveTimer.cancel();
        }
        
        autoSaveTimer = new Timer("EditorAutoSave", true);
        autoSaveTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                autoSave();
            }
        }, 30000, 30000); // 30 seconds
    }

    public boolean hasUnsavedChanges() {
        return hasUnsavedChanges;
    }

    public void cleanup() {
        if (autoSaveTimer != null) {
            autoSaveTimer.cancel();
        }
        if (editorStage != null) {
            editorStage.close();
        }
    }
}
