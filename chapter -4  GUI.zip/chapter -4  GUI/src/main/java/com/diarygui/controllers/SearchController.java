package com.diarygui.controllers;

import com.diarygui.models.DiaryEntry;
import com.diarygui.models.DiaryModel;
import com.diarygui.services.SearchService;
import com.diarygui.services.ThemeService;
import com.diarygui.tasks.SearchTask;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SearchController {
    private final DiaryModel diaryModel;
    private final SearchService searchService;
    private final ThemeService themeService;
    
    private Stage searchStage;
    private TextField searchField;
    private ComboBox<String> tagComboBox;
    private DatePicker startDatePicker;
    private DatePicker endDatePicker;
    private TextField minWordsField;
    private TextField maxWordsField;
    private CheckBox caseSensitiveCheckBox;
    private CheckBox regexCheckBox;
    private CheckBox wholeWordCheckBox;
    private ListView<SearchResultItem> resultsListView;
    private Label resultsLabel;
    private ProgressBar progressBar;
    private Label statusLabel;
    private Button searchButton;
    private Button clearButton;
    private Button closeButton;
    
    private ObservableList<SearchResultItem> resultsObservableList;
    private SearchService.SearchResult lastSearchResult;

    public SearchController(DiaryModel diaryModel, SearchService searchService, ThemeService themeService) {
        this.diaryModel = diaryModel;
        this.searchService = searchService;
        this.themeService = themeService;
        this.resultsObservableList = FXCollections.observableArrayList();
    }

    public void showSearchDialog(Stage ownerStage) {
        if (searchStage == null) {
            createSearchStage();
        }
        
        searchStage.initOwner(ownerStage);
        searchStage.show();
        searchStage.toFront();
        
        searchField.requestFocus();
    }

    private void createSearchStage() {
        searchStage = new Stage();
        searchStage.setTitle("Search Diary Entries");
        searchStage.initModality(Modality.APPLICATION_MODAL);
        searchStage.setWidth(900);
        searchStage.setHeight(700);
        
        VBox root = new VBox(15);
        root.getStyleClass().add("search-root");
        root.setPadding(new Insets(20));
        
        TitledPane searchOptionsPane = new TitledPane("Search Options", createSearchOptionsPane());
        searchOptionsPane.setExpanded(true);
        searchOptionsPane.getStyleClass().add("search-options-pane");
        
        TitledPane filtersPane = new TitledPane("Filters", createFiltersPane());
        filtersPane.setExpanded(false);
        filtersPane.getStyleClass().add("filters-pane");
        
        resultsListView = new ListView<>();
        resultsListView.setItems(resultsObservableList);
        resultsListView.setCellFactory(param -> new SearchResultCell());
        resultsListView.setPrefHeight(300);
        resultsListView.getStyleClass().add("results-list");
        
        resultsLabel = new Label("Enter search criteria and click Search");
        resultsLabel.getStyleClass().add("results-label");
        
        HBox progressBox = new HBox(10);
        progressBox.setAlignment(Pos.CENTER_LEFT);
        
        progressBar = new ProgressBar();
        progressBar.setPrefWidth(200);
        progressBar.setVisible(false);
        
        statusLabel = new Label("Ready");
        statusLabel.getStyleClass().add("status-label");
        
        progressBox.getChildren().addAll(progressBar, statusLabel);
        
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        
        searchButton = new Button("Search");
        searchButton.getStyleClass().add("primary-button");
        searchButton.setOnAction(e -> performSearch());
        searchButton.setDefaultButton(true);
        
        clearButton = new Button("Clear");
        clearButton.getStyleClass().add("secondary-button");
        clearButton.setOnAction(e -> clearSearch());
        
        closeButton = new Button("Close");
        closeButton.getStyleClass().add("secondary-button");
        closeButton.setOnAction(e -> searchStage.hide());
        
        buttonBox.getChildren().addAll(searchButton, clearButton, closeButton);
        
        root.getChildren().addAll(searchOptionsPane, filtersPane, resultsLabel, resultsListView, progressBox, buttonBox);
        
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource(themeService.getCommonStylesheet()).toExternalForm());
        scene.getStylesheets().add(getClass().getResource(themeService.getThemeStylesheet()).toExternalForm());
        
        searchStage.setScene(scene);
        
        setupEventHandlers();
        setupRealTimeSearch();
    }

    private VBox createSearchOptionsPane() {
        VBox optionsBox = new VBox(10);
        optionsBox.setPadding(new Insets(10));
        
        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER_LEFT);
        
        Label searchLabel = new Label("Search:");
        searchLabel.getStyleClass().add("search-label");
        
        searchField = new TextField();
        searchField.getStyleClass().add("search-field");
        searchField.setPromptText("Enter search terms...");
        HBox.setHgrow(searchField, Priority.ALWAYS);
        
        searchBox.getChildren().addAll(searchLabel, searchField);
        
        HBox optionsCheckBoxBox = new HBox(20);
        optionsCheckBoxBox.setAlignment(Pos.CENTER_LEFT);
        
        caseSensitiveCheckBox = new CheckBox("Case Sensitive");
        caseSensitiveCheckBox.getStyleClass().add("option-checkbox");
        
        regexCheckBox = new CheckBox("Use Regex");
        regexCheckBox.getStyleClass().add("option-checkbox");
        
        wholeWordCheckBox = new CheckBox("Whole Word");
        wholeWordCheckBox.getStyleClass().add("option-checkbox");
        
        optionsCheckBoxBox.getChildren().addAll(caseSensitiveCheckBox, regexCheckBox, wholeWordCheckBox);
        
        optionsBox.getChildren().addAll(searchBox, optionsCheckBoxBox);
        
        return optionsBox;
    }

    private VBox createFiltersPane() {
        VBox filtersBox = new VBox(15);
        filtersBox.setPadding(new Insets(10));
        
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(10);
        
        Label tagLabel = new Label("Tags:");
        tagLabel.getStyleClass().add("filter-label");
        grid.add(tagLabel, 0, 0);
        
        tagComboBox = new ComboBox<>();
        tagComboBox.getStyleClass().add("tag-combo");
        tagComboBox.setPromptText("Select tag...");
        tagComboBox.getItems().addAll(diaryModel.getAllTags());
        HBox.setHgrow(tagComboBox, Priority.ALWAYS);
        grid.add(tagComboBox, 1, 0);
        
        Label dateRangeLabel = new Label("Date Range:");
        dateRangeLabel.getStyleClass().add("filter-label");
        grid.add(dateRangeLabel, 0, 1);
        
        HBox dateBox = new HBox(10);
        dateBox.setAlignment(Pos.CENTER_LEFT);
        
        startDatePicker = new DatePicker();
        startDatePicker.getStyleClass().add("date-picker");
        startDatePicker.setPromptText("Start date");
        
        Label toLabel = new Label("to");
        toLabel.getStyleClass().add("filter-label");
        
        endDatePicker = new DatePicker();
        endDatePicker.getStyleClass().add("date-picker");
        endDatePicker.setPromptText("End date");
        
        dateBox.getChildren().addAll(startDatePicker, toLabel, endDatePicker);
        grid.add(dateBox, 1, 1);
        
        Label wordCountLabel = new Label("Word Count:");
        wordCountLabel.getStyleClass().add("filter-label");
        grid.add(wordCountLabel, 0, 2);
        
        HBox wordCountBox = new HBox(10);
        wordCountBox.setAlignment(Pos.CENTER_LEFT);
        
        minWordsField = new TextField();
        minWordsField.getStyleClass().add("word-count-field");
        minWordsField.setPromptText("Min");
        minWordsField.setPrefWidth(80);
        
        Label dashLabel = new Label("-");
        dashLabel.getStyleClass().add("filter-label");
        
        maxWordsField = new TextField();
        maxWordsField.getStyleClass().add("word-count-field");
        maxWordsField.setPromptText("Max");
        maxWordsField.setPrefWidth(80);
        
        wordCountBox.getChildren().addAll(minWordsField, dashLabel, maxWordsField);
        grid.add(wordCountBox, 1, 2);
        
        filtersBox.getChildren().add(grid);
        
        return filtersBox;
    }

    private void setupEventHandlers() {
        searchField.setOnAction(e -> performSearch());
        
        regexCheckBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal) {
                wholeWordCheckBox.setDisable(true);
                wholeWordCheckBox.setSelected(false);
            } else {
                wholeWordCheckBox.setDisable(false);
            }
        });
        
        resultsListView.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                showEntryPreview(newVal.getEntry());
            }
        });
        
        resultsListView.setRowFactory(tv -> {
            TableRow<SearchResultItem> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    SearchResultItem item = row.getItem();
                    openEntryInEditor(item.getEntry());
                }
            });
            return row;
        });
    }

    private void setupRealTimeSearch() {
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.length() >= 3 || newVal.isEmpty()) {
                performSearch();
            }
        });
    }

    private void performSearch() {
        String query = searchField.getText().trim();
        
        SearchService.SearchCriteria criteria = new SearchService.SearchCriteria(query)
            .caseSensitive(caseSensitiveCheckBox.isSelected())
            .useRegex(regexCheckBox.isSelected())
            .wholeWord(wholeWordCheckBox.isSelected());
        
        if (startDatePicker.getValue() != null || endDatePicker.getValue() != null) {
            criteria.withDateRange(startDatePicker.getValue(), endDatePicker.getValue());
        }
        
        Integer minWords = null;
        Integer maxWords = null;
        try {
            if (!minWordsField.getText().trim().isEmpty()) {
                minWords = Integer.parseInt(minWordsField.getText().trim());
            }
            if (!maxWordsField.getText().trim().isEmpty()) {
                maxWords = Integer.parseInt(maxWordsField.getText().trim());
            }
        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid word count values");
            return;
        }
        
        if (minWords != null || maxWords != null) {
            criteria.withWordCountRange(minWords, maxWords);
        }
        
        String selectedTag = tagComboBox.getValue();
        if (selectedTag != null && !selectedTag.isEmpty()) {
            criteria.withRequiredTags(List.of(selectedTag));
        }
        
        SearchTask task = new SearchTask(searchService, criteria);
        
        task.messageProperty().addListener((obs, oldMsg, newMsg) -> 
            Platform.runLater(() -> statusLabel.setText(newMsg)));
        
        task.progressProperty().addListener((obs, oldProgress, newProgress) -> 
            Platform.runLater(() -> progressBar.setProgress(newProgress.doubleValue())));
        
        task.setOnSucceeded(event -> {
            Platform.runLater(() -> {
                lastSearchResult = task.getValue();
                displayResults(lastSearchResult);
                progressBar.setVisible(false);
                searchButton.setDisable(false);
            });
        });
        
        task.setOnFailed(event -> {
            Platform.runLater(() -> {
                statusLabel.setText("Search failed: " + task.getException().getMessage());
                progressBar.setVisible(false);
                searchButton.setDisable(false);
                showError("Search Error", "Failed to perform search: " + task.getException().getMessage());
            });
        });
        
        progressBar.setVisible(true);
        searchButton.setDisable(true);
        statusLabel.setText("Searching...");
        
        Thread thread = new Thread(task);
        thread.setDaemon(true);
        thread.start();
    }

    private void displayResults(SearchService.SearchResult result) {
        resultsObservableList.clear();
        
        for (SearchService.SearchMatch match : result.getMatches()) {
            resultsObservableList.add(new SearchResultItem(match));
        }
        
        resultsLabel.setText(String.format("Found %d entries with %d total matches", 
            result.getEntryCount(), result.getTotalMatches()));
        statusLabel.setText("Search completed");
    }

    private void clearSearch() {
        searchField.clear();
        tagComboBox.setValue(null);
        startDatePicker.setValue(null);
        endDatePicker.setValue(null);
        minWordsField.clear();
        maxWordsField.clear();
        caseSensitiveCheckBox.setSelected(false);
        regexCheckBox.setSelected(false);
        wholeWordCheckBox.setSelected(false);
        
        resultsObservableList.clear();
        resultsLabel.setText("Enter search criteria and click Search");
        statusLabel.setText("Ready");
    }

    private void showEntryPreview(DiaryEntry entry) {
        // This could open a preview dialog or update a preview panel
        // For now, we'll just show a simple alert with entry info
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Entry Preview");
        alert.setHeaderText(entry.getTitle());
        alert.setContentText("Created: " + entry.getCreatedAt() + "\n" +
            "Words: " + entry.getWordCount() + "\n\n" +
            entry.getPreview());
        alert.showAndWait();
    }

    private void openEntryInEditor(DiaryEntry entry) {
        // This would open the entry in the main editor
        // For now, we'll just show a confirmation
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Open Entry");
        alert.setHeaderText("Open in Editor");
        alert.setContentText("This would open '" + entry.getTitle() + "' in the main editor.");
        alert.showAndWait();
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class SearchResultItem {
        private final DiaryEntry entry;
        private final List<SearchService.SearchMatch.Location> locations;

        public SearchResultItem(SearchService.SearchMatch match) {
            this.entry = match.getEntry();
            this.locations = match.getLocations();
        }

        public DiaryEntry getEntry() { return entry; }
        public List<SearchService.SearchMatch.Location> getLocations() { return locations; }
        
        @Override
        public String toString() {
            return entry.getTitle() + " (" + locations.size() + " matches)";
        }
    }

    private static class SearchResultCell extends ListCell<SearchResultItem> {
        @Override
        protected void updateItem(SearchResultItem item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
                setGraphic(null);
            } else {
                VBox content = new VBox(5);
                content.getStyleClass().add("search-result-cell");
                
                Label titleLabel = new Label(item.getEntry().getTitle());
                titleLabel.getStyleClass().add("result-title");
                
                Label dateLabel = new Label(item.getEntry().getCreatedAt().toString());
                dateLabel.getStyleClass().add("result-date");
                
                Label matchesLabel = new Label(item.getLocations().size() + " matches");
                matchesLabel.getStyleClass().add("result-matches");
                
                Label previewLabel = new Label(item.getEntry().getPreview());
                previewLabel.getStyleClass().add("result-preview");
                previewLabel.setWrapText(true);
                
                content.getChildren().addAll(titleLabel, dateLabel, matchesLabel, previewLabel);
                setGraphic(content);
            }
        }
    }
}
