package com.diarygui.tasks;

import com.diarygui.models.DiaryModel;
import com.diarygui.services.SearchService;
import javafx.concurrent.Task;

public class SearchTask extends Task<SearchService.SearchResult> {
    private final SearchService searchService;
    private final SearchService.SearchCriteria criteria;

    public SearchTask(SearchService searchService, SearchService.SearchCriteria criteria) {
        this.searchService = searchService;
        this.criteria = criteria;
    }

    @Override
    protected SearchService.SearchResult call() throws Exception {
        updateMessage("Searching: " + criteria.getQuery());
        updateProgress(0, 100);

        try {
            updateMessage("Analyzing search criteria...");
            updateProgress(10, 100);
            
            SearchService.SearchResult result = searchService.searchAsync(criteria).get();
            
            updateMessage("Found " + result.getEntryCount() + " entries with " + result.getTotalMatches() + " matches");
            updateProgress(100, 100);
            
            return result;
        } catch (Exception e) {
            updateMessage("Search failed: " + e.getMessage());
            throw e;
        }
    }
}
