package com.diarygui.tasks;

import com.diarygui.models.DiaryEntry;
import com.diarygui.services.FileService;
import javafx.concurrent.Task;

public class SaveEntryTask extends Task<Boolean> {
    private final FileService fileService;
    private final DiaryEntry entry;

    public SaveEntryTask(FileService fileService, DiaryEntry entry) {
        this.fileService = fileService;
        this.entry = entry;
    }

    @Override
    protected Boolean call() throws Exception {
        updateMessage("Saving entry: " + entry.getTitle());
        updateProgress(0, 100);

        try {
            updateMessage("Validating entry content...");
            updateProgress(20, 100);
            
            if (entry.getTitle() == null || entry.getTitle().trim().isEmpty()) {
                entry.setTitle("Untitled Entry");
            }
            
            updateMessage("Writing to file: " + entry.getFileName());
            updateProgress(50, 100);
            
            boolean success = fileService.saveEntryAsync(entry).get();
            
            if (success) {
                updateMessage("Entry saved successfully");
                updateProgress(100, 100);
            } else {
                updateMessage("Failed to save entry");
            }
            
            return success;
        } catch (Exception e) {
            updateMessage("Error saving entry: " + e.getMessage());
            throw e;
        }
    }
}
