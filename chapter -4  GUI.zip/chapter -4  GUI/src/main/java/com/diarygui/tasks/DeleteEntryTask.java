package com.diarygui.tasks;

import com.diarygui.models.DiaryEntry;
import com.diarygui.services.FileService;
import javafx.concurrent.Task;

public class DeleteEntryTask extends Task<Boolean> {
    private final FileService fileService;
    private final DiaryEntry entry;

    public DeleteEntryTask(FileService fileService, DiaryEntry entry) {
        this.fileService = fileService;
        this.entry = entry;
    }

    @Override
    protected Boolean call() throws Exception {
        updateMessage("Deleting entry: " + entry.getTitle());
        updateProgress(0, 100);

        try {
            updateMessage("Removing file: " + entry.getFileName());
            updateProgress(30, 100);
            
            boolean success = fileService.deleteEntryAsync(entry).get();
            
            if (success) {
                updateMessage("Entry deleted successfully");
                updateProgress(100, 100);
            } else {
                updateMessage("Failed to delete entry");
            }
            
            return success;
        } catch (Exception e) {
            updateMessage("Error deleting entry: " + e.getMessage());
            throw e;
        }
    }
}
