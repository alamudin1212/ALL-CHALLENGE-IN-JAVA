package com.diarygui.tasks;

import com.diarygui.models.DiaryEntry;
import com.diarygui.models.DiaryModel;
import com.diarygui.services.FileService;
import javafx.concurrent.Task;

import java.util.List;

public class LoadEntriesTask extends Task<List<DiaryEntry>> {
    private final FileService fileService;
    private final DiaryModel diaryModel;

    public LoadEntriesTask(FileService fileService, DiaryModel diaryModel) {
        this.fileService = fileService;
        this.diaryModel = diaryModel;
    }

    @Override
    protected List<DiaryEntry> call() throws Exception {
        updateMessage("Loading diary entries...");
        updateProgress(0, 100);

        try {
            updateMessage("Reading entries directory...");
            updateProgress(10, 100);
            
            List<DiaryEntry> entries = fileService.loadAllEntriesAsync().get();
            
            updateMessage("Processing " + entries.size() + " entries...");
            updateProgress(50, 100);
            
            diaryModel.clearEntries();
            for (DiaryEntry entry : entries) {
                diaryModel.addEntry(entry);
            }
            
            updateMessage("Successfully loaded " + entries.size() + " entries");
            updateProgress(100, 100);
            
            return entries;
        } catch (Exception e) {
            updateMessage("Failed to load entries: " + e.getMessage());
            throw e;
        }
    }
}
