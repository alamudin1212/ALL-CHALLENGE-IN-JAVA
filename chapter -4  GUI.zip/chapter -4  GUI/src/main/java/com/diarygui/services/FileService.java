package com.diarygui.services;

import com.diarygui.models.DiaryEntry;
import com.diarygui.models.DiaryModel;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

public class FileService {
    private static final String ENTRIES_DIR = "entries";
    private final Path entriesPath;
    private final DiaryModel diaryModel;

    public FileService(DiaryModel diaryModel) {
        this.diaryModel = diaryModel;
        this.entriesPath = Paths.get(ENTRIES_DIR);
        ensureEntriesDirectory();
    }

    private void ensureEntriesDirectory() {
        try {
            if (!Files.exists(entriesPath)) {
                Files.createDirectories(entriesPath);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to create entries directory", e);
        }
    }

    public CompletableFuture<List<DiaryEntry>> loadAllEntriesAsync() {
        return CompletableFuture.supplyAsync(() -> {
            List<DiaryEntry> entries = new ArrayList<>();
            try (Stream<Path> paths = Files.list(entriesPath)) {
                paths.filter(Files::isRegularFile)
                     .filter(path -> path.toString().endsWith(".txt"))
                     .sorted((p1, p2) -> {
                         try {
                             return Files.getLastModifiedTime(p2).compareTo(Files.getLastModifiedTime(p1));
                         } catch (IOException e) {
                             return 0;
                         }
                     })
                     .forEach(path -> {
                         try {
                             String content = Files.readString(path);
                             String fileName = path.getFileName().toString();
                             DiaryEntry entry = DiaryEntry.fromFileContent(content, fileName);
                             entries.add(entry);
                         } catch (IOException e) {
                             System.err.println("Failed to read entry: " + path + " - " + e.getMessage());
                         }
                     });
            } catch (IOException e) {
                System.err.println("Failed to list entries directory: " + e.getMessage());
            }
            return entries;
        });
    }

    public CompletableFuture<Boolean> saveEntryAsync(DiaryEntry entry) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Path entryPath = entriesPath.resolve(entry.getFileName());
                String content = entry.toFileContent();
                Files.writeString(entryPath, content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                return true;
            } catch (IOException e) {
                System.err.println("Failed to save entry: " + entry.getFileName() + " - " + e.getMessage());
                return false;
            }
        });
    }

    public CompletableFuture<Boolean> deleteEntryAsync(DiaryEntry entry) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Path entryPath = entriesPath.resolve(entry.getFileName());
                Files.deleteIfExists(entryPath);
                return true;
            } catch (IOException e) {
                System.err.println("Failed to delete entry: " + entry.getFileName() + " - " + e.getMessage());
                return false;
            }
        });
    }

    public CompletableFuture<Boolean> backupEntriesAsync(Path backupPath) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                if (!Files.exists(backupPath.getParent())) {
                    Files.createDirectories(backupPath.getParent());
                }
                
                try (Stream<Path> paths = Files.walk(entriesPath)) {
                    paths.filter(Files::isRegularFile)
                         .forEach(source -> {
                             try {
                                 Path relative = entriesPath.relativize(source);
                                 Path destination = backupPath.resolve(relative);
                                 Files.createDirectories(destination.getParent());
                                 Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
                             } catch (IOException e) {
                                 System.err.println("Failed to backup file: " + source + " - " + e.getMessage());
                             }
                         });
                }
                return true;
            } catch (IOException e) {
                System.err.println("Failed to create backup: " + e.getMessage());
                return false;
            }
        });
    }

    public CompletableFuture<Boolean> importEntryAsync(Path importPath) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                if (!Files.exists(importPath) || !Files.isRegularFile(importPath)) {
                    return false;
                }
                
                String content = Files.readString(importPath);
                String fileName = importPath.getFileName().toString();
                
                if (!fileName.endsWith(".txt")) {
                    fileName = fileName + ".txt";
                }
                
                DiaryEntry entry = DiaryEntry.fromFileContent(content, fileName);
                if (entry.getTitle().isEmpty()) {
                    entry.setTitle("Imported Entry");
                }
                
                diaryModel.addEntry(entry);
                return saveEntryAsync(entry).get();
            } catch (Exception e) {
                System.err.println("Failed to import entry: " + importPath + " - " + e.getMessage());
                return false;
            }
        });
    }

    public CompletableFuture<Boolean> exportEntryAsync(DiaryEntry entry, Path exportPath) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                if (!Files.exists(exportPath.getParent())) {
                    Files.createDirectories(exportPath.getParent());
                }
                
                String content = entry.toFileContent();
                Files.writeString(exportPath, content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                return true;
            } catch (IOException e) {
                System.err.println("Failed to export entry: " + entry.getFileName() + " - " + e.getMessage());
                return false;
            }
        });
    }

    public long getTotalEntriesSize() {
        try {
            return Files.list(entriesPath)
                       .filter(Files::isRegularFile)
                       .mapToLong(path -> {
                           try {
                               return Files.size(path);
                           } catch (IOException e) {
                               return 0;
                           }
                       })
                       .sum();
        } catch (IOException e) {
            return 0;
        }
    }

    public int getEntriesCount() {
        try {
            return (int) Files.list(entriesPath)
                           .filter(Files::isRegularFile)
                           .filter(path -> path.toString().endsWith(".txt"))
                           .count();
        } catch (IOException e) {
            return 0;
        }
    }

    public Path getEntriesPath() {
        return entriesPath;
    }

    public boolean entriesDirectoryExists() {
        return Files.exists(entriesPath) && Files.isDirectory(entriesPath);
    }

    public CompletableFuture<List<String>> findCorruptedEntriesAsync() {
        return CompletableFuture.supplyAsync(() -> {
            List<String> corruptedFiles = new ArrayList<>();
            try (Stream<Path> paths = Files.list(entriesPath)) {
                paths.filter(Files::isRegularFile)
                     .filter(path -> path.toString().endsWith(".txt"))
                     .forEach(path -> {
                         try {
                             String content = Files.readString(path);
                             String fileName = path.getFileName().toString();
                             DiaryEntry.fromFileContent(content, fileName);
                         } catch (Exception e) {
                             corruptedFiles.add(path.getFileName().toString());
                         }
                     });
            } catch (IOException e) {
                System.err.println("Failed to scan for corrupted entries: " + e.getMessage());
            }
            return corruptedFiles;
        });
    }
}
