package com.diarygui.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class ThemeService {
    private static final String SETTINGS_FILE = "diary-settings.properties";
    private static final String THEME_KEY = "current.theme";
    private static final String AUTO_SAVE_KEY = "auto.save.enabled";
    private static final String AUTO_SAVE_INTERVAL_KEY = "auto.save.interval";
    
    private String currentTheme;
    private final Properties settings;

    public ThemeService() {
        this.settings = new Properties();
        this.currentTheme = "light";
        loadSettings();
    }

    private void loadSettings() {
        Path settingsPath = Paths.get(SETTINGS_FILE);
        if (Files.exists(settingsPath)) {
            try {
                settings.load(Files.newInputStream(settingsPath));
                currentTheme = settings.getProperty(THEME_KEY, "light");
            } catch (IOException e) {
                System.err.println("Failed to load settings: " + e.getMessage());
            }
        }
    }

    private void saveSettings() {
        try {
            settings.setProperty(THEME_KEY, currentTheme);
            settings.store(Files.newOutputStream(Paths.get(SETTINGS_FILE)), "Diary Manager Settings");
        } catch (IOException e) {
            System.err.println("Failed to save settings: " + e.getMessage());
        }
    }

    public void setTheme(String theme) {
        if (theme != null && (theme.equals("light") || theme.equals("dark"))) {
            this.currentTheme = theme;
            saveSettings();
        }
    }

    public String getCurrentTheme() {
        return currentTheme;
    }

    public void toggleTheme() {
        currentTheme = currentTheme.equals("light") ? "dark" : "light";
        saveSettings();
    }

    public String getThemeStylesheet() {
        return switch (currentTheme) {
            case "dark" -> "/com/diarygui/dark-theme.css";
            default -> "/com/diarygui/light-theme.css";
        };
    }

    public String getCommonStylesheet() {
        return "/com/diarygui/common.css";
    }

    public void setAutoSaveEnabled(boolean enabled) {
        settings.setProperty(AUTO_SAVE_KEY, String.valueOf(enabled));
        saveSettings();
    }

    public boolean isAutoSaveEnabled() {
        return Boolean.parseBoolean(settings.getProperty(AUTO_SAVE_KEY, "true"));
    }

    public void setAutoSaveInterval(int interval) {
        settings.setProperty(AUTO_SAVE_INTERVAL_KEY, String.valueOf(interval));
        saveSettings();
    }

    public int getAutoSaveInterval() {
        return Integer.parseInt(settings.getProperty(AUTO_SAVE_INTERVAL_KEY, "30"));
    }

    public boolean isDarkTheme() {
        return "dark".equals(currentTheme);
    }

    public String getThemeColor(String colorType) {
        return switch (currentTheme) {
            case "dark" -> switch (colorType) {
                case "background" -> "#2D2D2D";
                case "surface" -> "#3C3C3C";
                case "primary" -> "#BB86FC";
                case "secondary" -> "#03DAC6";
                case "text" -> "#E0E0E0";
                case "text-secondary" -> "#B0B0B0";
                case "border" -> "#4A4A4A";
                case "accent" -> "#CF6679";
                default -> "#FFFFFF";
            };
            default -> switch (colorType) {
                case "background" -> "#FFFFFF";
                case "surface" -> "#F5F5F5";
                case "primary" -> "#1976D2";
                case "secondary" -> "#4CAF50";
                case "text" -> "#212121";
                case "text-secondary" -> "#757575";
                case "border" -> "#E0E0E0";
                case "accent" -> "#FF5722";
                default -> "#000000";
            };
        };
    }
}
