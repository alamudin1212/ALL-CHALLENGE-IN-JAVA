package com.diarygui.services;

import com.diarygui.models.DiaryEntry;
import com.diarygui.models.DiaryModel;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class SearchService {
    private final DiaryModel diaryModel;
    private String lastQuery;
    private List<DiaryEntry> lastResults;

    public SearchService(DiaryModel diaryModel) {
        this.diaryModel = diaryModel;
        this.lastQuery = "";
        this.lastResults = new ArrayList<>();
    }

    public CompletableFuture<SearchResult> searchAsync(SearchCriteria criteria) {
        return CompletableFuture.supplyAsync(() -> performSearch(criteria));
    }

    private SearchResult performSearch(SearchCriteria criteria) {
        List<DiaryEntry> allEntries = diaryModel.getAllEntries();
        List<SearchMatch> matches = new ArrayList<>();
        
        String query = criteria.getQuery();
        if (query == null || query.trim().isEmpty()) {
            return new SearchResult(matches, criteria, 0);
        }

        String lowerQuery = query.toLowerCase();
        boolean useRegex = criteria.isUseRegex();
        boolean caseSensitive = criteria.isCaseSensitive();
        boolean wholeWord = criteria.isWholeWord();

        Pattern pattern = null;
        if (useRegex) {
            try {
                int flags = caseSensitive ? 0 : Pattern.CASE_INSENSITIVE;
                pattern = Pattern.compile(query, flags);
            } catch (Exception e) {
                return new SearchResult(matches, criteria, 0);
            }
        }

        int totalMatches = 0;
        for (DiaryEntry entry : allEntries) {
            if (!matchesDateCriteria(entry, criteria)) {
                continue;
            }
            
            if (!matchesWordCountCriteria(entry, criteria)) {
                continue;
            }
            
            if (!matchesTagCriteria(entry, criteria)) {
                continue;
            }

            List<SearchMatch.Location> locations = new ArrayList<>();
            
            locations.addAll(searchInText(entry.getTitle(), "title", entry, criteria, pattern, lowerQuery, caseSensitive, wholeWord));
            locations.addAll(searchInText(entry.getContent(), "content", entry, criteria, pattern, lowerQuery, caseSensitive, wholeWord));
            locations.addAll(searchInTags(entry, criteria, pattern, lowerQuery, caseSensitive, wholeWord));

            if (!locations.isEmpty()) {
                matches.add(new SearchMatch(entry, locations));
                totalMatches += locations.size();
            }
        }

        lastQuery = query;
        lastResults = matches.stream().map(SearchMatch::getEntry).toList();
        
        return new SearchResult(matches, criteria, totalMatches);
    }

    private List<SearchMatch.Location> searchInText(String text, String fieldType, DiaryEntry entry, 
                                                    SearchCriteria criteria, Pattern pattern, 
                                                    String lowerQuery, boolean caseSensitive, boolean wholeWord) {
        List<SearchMatch.Location> locations = new ArrayList<>();
        if (text == null || text.isEmpty()) return locations;

        String searchText = caseSensitive ? text : text.toLowerCase();
        
        if (pattern != null) {
            Matcher matcher = pattern.matcher(text);
            while (matcher.find()) {
                int start = matcher.start();
                int end = matcher.end();
                String context = extractContext(text, start, end, 50);
                locations.add(new SearchMatch.Location(fieldType, start, end, matcher.group(), context));
            }
        } else {
            String searchPattern = wholeWord ? "\\b" + Pattern.quote(lowerQuery) + "\\b" : Pattern.quote(lowerQuery);
            Pattern searchRegex = Pattern.compile(searchPattern);
            Matcher matcher = searchRegex.matcher(searchText);
            
            while (matcher.find()) {
                int start = matcher.start();
                int end = matcher.end();
                String matchedText = text.substring(start, end);
                String context = extractContext(text, start, end, 50);
                locations.add(new SearchMatch.Location(fieldType, start, end, matchedText, context));
            }
        }
        
        return locations;
    }

    private List<SearchMatch.Location> searchInTags(DiaryEntry entry, SearchCriteria criteria, 
                                                    Pattern pattern, String lowerQuery, 
                                                    boolean caseSensitive, boolean wholeWord) {
        List<SearchMatch.Location> locations = new ArrayList<>();
        
        for (String tag : entry.getTags()) {
            String tagText = caseSensitive ? tag : tag.toLowerCase();
            
            boolean matches = false;
            if (pattern != null) {
                matches = pattern.matcher(tag).find();
            } else if (wholeWord) {
                matches = tagText.equals(lowerQuery);
            } else {
                matches = tagText.contains(lowerQuery);
            }
            
            if (matches) {
                String context = "Tag: " + tag;
                locations.add(new SearchMatch.Location("tag", 0, tag.length(), tag, context));
            }
        }
        
        return locations;
    }

    private String extractContext(String text, int start, int end, int contextLength) {
        int contextStart = Math.max(0, start - contextLength);
        int contextEnd = Math.min(text.length(), end + contextLength);
        
        String context = text.substring(contextStart, contextEnd);
        if (contextStart > 0) context = "..." + context;
        if (contextEnd < text.length()) context = context + "...";
        
        return context;
    }

    private boolean matchesDateCriteria(DiaryEntry entry, SearchCriteria criteria) {
        LocalDate startDate = criteria.getStartDate();
        LocalDate endDate = criteria.getEndDate();
        
        if (startDate != null && endDate != null) {
            LocalDate entryDate = entry.getCreatedAt().toLocalDate();
            return !entryDate.isBefore(startDate) && !entryDate.isAfter(endDate);
        } else if (startDate != null) {
            LocalDate entryDate = entry.getCreatedAt().toLocalDate();
            return !entryDate.isBefore(startDate);
        } else if (endDate != null) {
            LocalDate entryDate = entry.getCreatedAt().toLocalDate();
            return !entryDate.isAfter(endDate);
        }
        
        return true;
    }

    private boolean matchesWordCountCriteria(DiaryEntry entry, SearchCriteria criteria) {
        Integer minWords = criteria.getMinWords();
        Integer maxWords = criteria.getMaxWords();
        
        int wordCount = entry.getWordCount();
        
        if (minWords != null && wordCount < minWords) {
            return false;
        }
        
        if (maxWords != null && wordCount > maxWords) {
            return false;
        }
        
        return true;
    }

    private boolean matchesTagCriteria(DiaryEntry entry, SearchCriteria criteria) {
        List<String> requiredTags = criteria.getRequiredTags();
        List<String> excludedTags = criteria.getExcludedTags();
        
        if (requiredTags != null && !requiredTags.isEmpty()) {
            for (String tag : requiredTags) {
                if (!entry.hasTag(tag)) {
                    return false;
                }
            }
        }
        
        if (excludedTags != null && !excludedTags.isEmpty()) {
            for (String tag : excludedTags) {
                if (entry.hasTag(tag)) {
                    return false;
                }
            }
        }
        
        return true;
    }

    public List<String> getSuggestions(String partialQuery) {
        List<String> suggestions = new ArrayList<>();
        if (partialQuery == null || partialQuery.length() < 2) return suggestions;
        
        String lowerPartial = partialQuery.toLowerCase();
        
        for (DiaryEntry entry : diaryModel.getAllEntries()) {
            for (String tag : entry.getTags()) {
                if (tag.toLowerCase().contains(lowerPartial) && !suggestions.contains(tag)) {
                    suggestions.add(tag);
                }
            }
        }
        
        suggestions.sort(String::compareTo);
        if (suggestions.size() > 10) {
            suggestions = suggestions.subList(0, 10);
        }
        
        return suggestions;
    }

    public String getLastQuery() {
        return lastQuery;
    }

    public List<DiaryEntry> getLastResults() {
        return new ArrayList<>(lastResults);
    }

    public static class SearchCriteria {
        private String query;
        private LocalDate startDate;
        private LocalDate endDate;
        private Integer minWords;
        private Integer maxWords;
        private List<String> requiredTags;
        private List<String> excludedTags;
        private boolean caseSensitive;
        private boolean useRegex;
        private boolean wholeWord;

        public SearchCriteria(String query) {
            this.query = query;
            this.caseSensitive = false;
            this.useRegex = false;
            this.wholeWord = false;
        }

        public SearchCriteria withDateRange(LocalDate startDate, LocalDate endDate) {
            this.startDate = startDate;
            this.endDate = endDate;
            return this;
        }

        public SearchCriteria withWordCountRange(Integer minWords, Integer maxWords) {
            this.minWords = minWords;
            this.maxWords = maxWords;
            return this;
        }

        public SearchCriteria withRequiredTags(List<String> tags) {
            this.requiredTags = tags;
            return this;
        }

        public SearchCriteria withExcludedTags(List<String> tags) {
            this.excludedTags = tags;
            return this;
        }

        public SearchCriteria caseSensitive(boolean caseSensitive) {
            this.caseSensitive = caseSensitive;
            return this;
        }

        public SearchCriteria useRegex(boolean useRegex) {
            this.useRegex = useRegex;
            return this;
        }

        public SearchCriteria wholeWord(boolean wholeWord) {
            this.wholeWord = wholeWord;
            return this;
        }

        public String getQuery() { return query; }
        public LocalDate getStartDate() { return startDate; }
        public LocalDate getEndDate() { return endDate; }
        public Integer getMinWords() { return minWords; }
        public Integer getMaxWords() { return maxWords; }
        public List<String> getRequiredTags() { return requiredTags; }
        public List<String> getExcludedTags() { return excludedTags; }
        public boolean isCaseSensitive() { return caseSensitive; }
        public boolean isUseRegex() { return useRegex; }
        public boolean isWholeWord() { return wholeWord; }
    }

    public static class SearchResult {
        private final List<SearchMatch> matches;
        private final SearchCriteria criteria;
        private final int totalMatches;

        public SearchResult(List<SearchMatch> matches, SearchCriteria criteria, int totalMatches) {
            this.matches = new ArrayList<>(matches);
            this.criteria = criteria;
            this.totalMatches = totalMatches;
        }

        public List<SearchMatch> getMatches() { return new ArrayList<>(matches); }
        public SearchCriteria getCriteria() { return criteria; }
        public int getTotalMatches() { return totalMatches; }
        public int getEntryCount() { return matches.size(); }
    }

    public static class SearchMatch {
        private final DiaryEntry entry;
        private final List<Location> locations;

        public SearchMatch(DiaryEntry entry, List<Location> locations) {
            this.entry = entry;
            this.locations = new ArrayList<>(locations);
        }

        public DiaryEntry getEntry() { return entry; }
        public List<Location> getLocations() { return new ArrayList<>(locations); }

        public static class Location {
            private final String fieldType;
            private final int start;
            private final int end;
            private final String matchedText;
            private final String context;

            public Location(String fieldType, int start, int end, String matchedText, String context) {
                this.fieldType = fieldType;
                this.start = start;
                this.end = end;
                this.matchedText = matchedText;
                this.context = context;
            }

            public String getFieldType() { return fieldType; }
            public int getStart() { return start; }
            public int getEnd() { return end; }
            public String getMatchedText() { return matchedText; }
            public String getContext() { return context; }
        }
    }
}
