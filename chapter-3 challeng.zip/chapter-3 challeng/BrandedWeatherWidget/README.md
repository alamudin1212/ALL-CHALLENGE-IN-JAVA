# Urban Pulse Labs — Branded Weather Widget (JavaFX)

A university assignment project: **Chapter 3 Challenge: Branded Weather Widget — Multiple Company Options**.

This widget is branded for **Urban Pulse Labs**, a smart-city technology company focused on data-driven urban analytics. The UI is designed as a clean, modular “micro-dashboard” that helps residents and commuters quickly understand weather conditions and how they affect the city.

## Company Choice & Justification

**Chosen company:** Urban Pulse Labs  
**Industry:** Smart City Technology & Urban Analytics  
**Brand values:** Innovative, Data-Driven, Urban, Connected  
**Target users:** City planners, commuters, urban residents  
**Mission:** Transforming how cities interact with environmental data  

The widget emphasizes *actionable city impact* (commute + UV + transit suggestion) rather than only “pretty weather,” aligning with a smart-city analytics brand.

---

## DESIGN RATIONALE

### Color Palette (with WCAG-conscious contrast)

- **Primary:** `#2C3E50` (deep urban slate)
- **Secondary:** `#34495E` (concrete grey-blue)
- **Accent:** `#3498DB` (tech blue highlight)

**Justification:** Concrete-inspired dark surfaces provide strong contrast for light text and allow the accent blue to communicate "data signals" and interactivity.

### Typography

- **Headings:** `Segoe UI` / `Roboto` (sans-serif)
- **Body:** `Segoe UI` / `Open Sans` (sans-serif)

**Justification:** Modern system-friendly sans-serif fonts reinforce a clean, tech-forward identity and ensure readability across platforms.

### Layout & Information Hierarchy

- **BorderPane root:** Enforces a classic widget layout.
- **Top:** Brand/city heading + search controls.
- **Center:** Primary conditions (temperature + description) + *urban network/radar shape*.
- **Bottom:** 3-day forecast cards for fast scanning.

The interface uses a modular structure similar to smart-city dashboards (cards, subtle borders, clear hierarchy).

---

## COMPANY-SPECIFIC ENHANCEMENTS (Urban Pulse Labs)

- **Commute Impact indicator:** Low / Moderate / High (styled with color-coded borders)
- **UV index display:** Prominent and categorized
- **Public transportation suggestion:** Simple guidance message (metro/bus/bike/ride-share)
- **Theme shape:** City network/radar hex with nodes and links
- **Animation:** A subtle pulsing node to simulate “live urban data”

---

## CSS ARCHITECTURE NOTE

All visual styling is handled via **external CSS** (`resources/style.css`) using:

- CSS variables (brand palette)
- Class-based styling (no inline `setStyle(...)`)
- Consistent component classes (cards, metrics, buttons)

This improves maintainability and makes brand iteration easy.

---

## Reflection

### Brand Alignment

Urban Pulse Labs implies *measurement, systems, and connectivity*. The pulsing node and linked network shape visually communicates “sensor networks” and “data flow,” while the commute/UV/transit modules translate weather into practical city outcomes.

### Why External CSS Matters

External CSS enables:

- Rapid theme iteration without touching logic
- Reusable design tokens (colors, spacing)
- Cleaner Java code with fewer visual concerns

### Integration Challenges

- Keeping all styling in CSS (no inline styles) while still achieving a polished, cohesive layout
- Making the animation subtle enough for a “dashboard” feel (not distracting)
- Ensuring input validation and error states stay user-friendly

---

## How to Run

### Requirements

- Java 17+ recommended
- JavaFX SDK configured in your IDE (IntelliJ/Eclipse/VS Code)

### Run

1. Open the project folder: `BrandedWeatherWidget/`
2. Ensure `resources/style.css` exists (relative to the project root).
3. Run:
   - `com.brandwidget.Main`

> If you use modules, you may need VM options like:
> `--module-path <path-to-javafx-lib> --add-modules javafx.controls`

---

## Screenshot

See: `screenshot.png` (replace the placeholder with a real screenshot after running the app).
